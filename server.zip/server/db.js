const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',        // change if your username is different
  password: 'Mysql26',        // put your MySQL password here
  database: 'fruit_node'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('🟢 Connected to MySQL database!');
});

module.exports = connection;
