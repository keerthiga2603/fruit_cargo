const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/:vendorId', (req, res) => {
  const vendorId = req.params.vendorId;
  db.query('SELECT * FROM products WHERE vendor_id = ?', [vendorId], (err, results) => {
    if (err) {
      res.status(500).send('Error getting products');
    } else {
      res.json(results);
    }
  });
});

module.exports = router;
