const express = require('express');
const router = express.Router();
const db = require('../db');

// Add item to cart
router.post('/add', (req, res) => {
  const { product_id, product_name, vendor_id, quantity, price } = req.body;
  const total_price = quantity * price;

  const sql = 'INSERT INTO cart (product_id, product_name, vendor_id, quantity, price, total_price) VALUES (?, ?, ?, ?, ?, ?)';
  db.query(sql, [product_id, product_name, vendor_id, quantity, price, total_price], (err, result) => {
    if (err) {
      res.status(500).send('Error adding to cart');
    } else {
      res.send('Item added to cart!');
    }
  });
});

// Get cart items
router.get('/', (req, res) => {
  db.query('SELECT * FROM cart', (err, results) => {
    if (err) {
      res.status(500).send('Error getting cart items');
    } else {
      res.json(results);
    }
  });
});

module.exports = router;
