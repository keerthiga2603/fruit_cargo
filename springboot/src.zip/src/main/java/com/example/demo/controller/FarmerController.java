package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.Farmer;
import com.example.demo.repository.FarmerRepository;

@Controller
@RequestMapping("/farmers")
public class FarmerController {

    @Autowired
    private FarmerRepository farmerRepository;

    @GetMapping
    public String listFarmers(Model model) {
        List<Farmer> farmers = farmerRepository.findAll();
        model.addAttribute("farmers", farmers);
        return "index";
    }

    @PostMapping("/add")
    public String addFarmer(@ModelAttribute Farmer farmer) {
        farmerRepository.save(farmer);
        return "redirect:/farmers";
    }

    @GetMapping("/delete/{id}")
    public String deleteFarmer(@PathVariable Long id) {
        farmerRepository.deleteById(id);
        return "redirect:/farmers";
    }
}
